package com.java.inh;

public class C1 {

	public C1() {
		System.out.println("Base Class Constructor...");
	}
}
