package com.java.inh;

public class Inh {
	public static void main(String[] args) {
		Second obj = new Second();
		obj.show();
		obj.display();
	}
}
