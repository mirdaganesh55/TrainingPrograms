package com.java.inh;

public class Second extends First {

	public void display() {
		System.out.println("Display method from Second Class..");
	}
}
