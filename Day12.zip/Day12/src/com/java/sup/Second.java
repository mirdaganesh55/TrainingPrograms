package com.java.sup;

public class Second extends First {

	public void show() {
		super.show();
		System.out.println("Show Method from Class Second...");
	}
}
