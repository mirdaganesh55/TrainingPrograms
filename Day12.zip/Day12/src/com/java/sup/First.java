package com.java.sup;

public class First {

	public void show() {
		System.out.println("Show Method from Class First...");
	}
}
