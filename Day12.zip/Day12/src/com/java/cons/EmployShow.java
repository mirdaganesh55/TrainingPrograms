package com.java.cons;

public class EmployShow {

	public static void main(String[] args) {
		Employ employ = new Employ(1, "Prasanna", 58822);
		System.out.println(employ);
	}
}
