package com.java.oops;

public class Student {

	int studentId;
	String name;
	Course course;
	double cgp;
}
