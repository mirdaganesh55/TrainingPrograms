package com.java.oops;

public enum Course {
	JAVA, DOTNET, ANGULAR, REACT
}
