package com.java.abst;

public class Rajesh extends Training {

	@Override
	void name() {
		System.out.println("Name is Rajesh...");
	}

	@Override
	void email() {
		System.out.println("Email is Rajesh@gmail.com");
	}

}