package com.java.abst;

public class Shivangi extends Employ {

	public Shivangi(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
