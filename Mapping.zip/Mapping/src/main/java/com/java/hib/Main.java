package com.java.hib;

public class Main {
	
	public static void main(String[] args) {
		System.out.println(new CustomerDAOImpl().showCustomerDetails());
	}
}
