package com.java.hib;

public enum Status {
	
	ACTIVE,INACTIVE
	
}
